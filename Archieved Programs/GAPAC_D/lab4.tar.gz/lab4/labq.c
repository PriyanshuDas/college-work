#include<stdio.h>
#include<string.h>

#define READ 0
#define WRITE 1

main()
{
	char * phrase = "This is CSE A";

	int fd[2], bytesread;
	char message[100];
	pipe(fd);
	if( fork() == 0)
	{	printf("CHILD");
		close ( fd[READ]);
		write( fd[WRITE],phrase,strlen(phrase)+1);
		close(fd[WRITE]);
	}
	else
	{
		printf("Parent");
		close(fd[WRITE]);
		bytesread=read(fd[READ],message,100);
		
		printf("Read %d bytes: %s\n",bytesread,message );
	}


}