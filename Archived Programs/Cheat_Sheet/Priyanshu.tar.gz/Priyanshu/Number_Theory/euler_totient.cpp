vector<int> Factors[limit];

ll euler_tot(ll N)
{
    ll ans = N;
    for(int i = 0; i < Factors[N].size(); i++)
    {
        ans -= ans/Factors[N][i];
    }
    return ans;
}
